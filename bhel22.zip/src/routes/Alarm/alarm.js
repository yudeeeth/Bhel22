import React from 'react'
import Modal from './component/warning'
const Alarm = () => {
  return (
    <div> 
      <Modal />
    </div>
  )
}

export default Alarm