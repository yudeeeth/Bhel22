import React from 'react'
import './help.css'
const Help = () => {
  return (
    <div className='help-main'>
    <div className="help-title">
        BHELSONIC 20i HMI version information
    </div>
    <div className='help-info'>
        lorem ipsum dolor sit color 
        <br/>
        version number: 1.0
        <br/>
        Github Repo: link
        <br/>
        Instructions readme: link
        <br/>
        Liscence information: MIT open source liscense
    </div>
    </div>
  )
}

export default Help